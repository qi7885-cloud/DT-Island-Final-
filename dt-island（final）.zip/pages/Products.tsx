import React from 'react';
import { Box } from 'lucide-react';
import { Interactive3DBox } from '../components/Interactive3DBox';
import { InteractiveRobotHand } from '../components/InteractiveRoboticArm';

export const Products: React.FC = () => {
  const features = [
    {
      title: '看得见',
      description: '轻量级3D交互模型，客户无需安装任何插件，即可在微信或浏览器中720°无死角地自主探索产品，洞悉每一个技术细节。打破时空限制，让产品自己“展示”自己。'
    },
    {
      title: '听得懂',
      description: '自动语音导览，支持多语言讲解，将复杂的技术参数、核心卖点，转化为客户一听就懂的优势。确保每一次产品介绍都标准、专业、到位，解放销售人力。'
    },
    {
      title: '问得出',
      description: '内置AI智能问答系统,基于您的产品知识库，能实时、准确地解答客户的各种疑问。扫清客户认知障碍，快速建立专业信任感，有效降低沟通成本。'
    },
    {
      title: '推得动',
      description: '智能Agent模块在后台默默工作，它主动引导客户的探索路径，适时推送相关资料，并将客户的关键互动行为转化为高热度销售信号，实时推送给销售团队，实现精准跟进。'
    }
  ];

  return (
    <div className="bg-slate-900 min-h-screen pt-20">
      
      {/* Product 1: Smart Card */}
      <section className="py-20 relative overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            
            <div className="space-y-8 animate-in slide-in-from-left duration-700">
              <div className="inline-block px-3 py-1 bg-cyan-500/10 text-cyan-400 rounded-full text-xs font-bold border border-cyan-500/20">
                PRODUCT 01
              </div>
              <h1 className="text-4xl md:text-6xl font-bold text-white">
                智能产品名片
              </h1>
              <p className="text-xl text-slate-400 leading-relaxed">
                轻量、高效、智能化的解决方案，化解工业设备的物理桎梏，将产品装进“口袋”，通过微米级高精度三维模型，随时随地进行沉浸式展示。
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {features.map((item, idx) => (
                  <div key={idx} className="p-5 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/30 transition-colors group">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)] group-hover:shadow-[0_0_12px_rgba(34,211,238,1)] transition-shadow"></div>
                      <h3 className="text-white font-bold text-lg">{item.title}</h3>
                    </div>
                    <p className="text-slate-400 text-sm leading-relaxed text-justify">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>

              <div className="pt-8 border-t border-slate-800">
                <h3 className="text-sm font-mono text-slate-500 mb-6">营销效果量化</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {[
                    { label: '客户留存提升', value: '8x' },
                    { label: '首次深度需求', value: '>90%' },
                    { label: '转化率', value: '>30%' },
                    { label: '速度提升', value: '10x' }
                  ].map((stat, idx) => (
                    <div key={idx} className="text-center">
                       <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                       <div className="text-xs text-slate-500">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Simulated Phone/3D View */}
            <div className="relative flex justify-center animate-in slide-in-from-right duration-700 lg:sticky lg:top-32">
                <div className="w-[300px] h-[600px] border-8 border-slate-800 rounded-[3rem] bg-slate-950 relative overflow-hidden shadow-2xl ring-1 ring-white/10">
                    <InteractiveRobotHand />
                </div>
            </div>

          </div>
        </div>
      </section>

      {/* Product 2: 3D Editor */}
      <section className="py-20 bg-slate-950 border-t border-slate-800">
        <div className="container mx-auto px-6">
           <div className="text-center mb-16 max-w-3xl mx-auto">
             <div className="inline-block px-3 py-1 bg-purple-500/10 text-purple-400 rounded-full text-xs font-bold border border-purple-500/20 mb-4">
                PRODUCT 02
             </div>
             <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">自研 3D 编辑器平台</h2>
             <p className="text-xl text-slate-400 leading-relaxed">
               无需编写复杂的图形算法和物理模拟代码。通过可视化界面和节点系统，构建出专业的3D模型、动画、视频等一站式解决方案。
             </p>
           </div>

           <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1">
                 <Interactive3DBox />
              </div>
              
              <div className="order-1 lg:order-2 space-y-8">
                 <div className="space-y-6">
                    {[
                        { title: '可视化节点系统', desc: '拖拽式操作，实时预览效果，所见即所得。' },
                        { title: '兼容经典工作流', desc: '支持主流 3D 格式导入，无缝衔接现有资产。' },
                        { title: '无限创意释放', desc: '专注于设计与创意，繁琐的渲染逻辑交给我们。' }
                    ].map((item, idx) => (
                        <div key={idx} className="flex gap-4">
                            <div className="w-10 h-10 rounded bg-slate-800 flex-shrink-0 flex items-center justify-center text-purple-400 border border-slate-700">
                                <span className="font-bold">{idx + 1}</span>
                            </div>
                            <div>
                                <h4 className="text-white font-bold text-lg">{item.title}</h4>
                                <p className="text-slate-400 text-sm mt-1">{item.desc}</p>
                            </div>
                        </div>
                    ))}
                 </div>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
};