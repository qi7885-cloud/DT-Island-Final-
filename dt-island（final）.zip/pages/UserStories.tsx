import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  QrCode, 
  Video, 
  BarChart2, 
  AlertTriangle, 
  Search, 
  FileText, 
  Settings, 
  CheckCircle2, 
  TrendingUp,
  Clock,
  ShieldCheck,
  MessageSquare,
  Database,
  Users,
  Zap,
  Target,
  PenTool,
  Ruler,
  ClipboardCheck,
  GitPullRequest,
  Layout,
  Box,
  Mic,
  Radio,
  Bot
} from 'lucide-react';

interface StoryChallenge {
  title: string;
  desc: string;
  icon: React.ElementType;
  color: string;
  border: string;
}

interface StorySolution {
  title: string;
  desc: string | string[];
  features?: string[];
  icon: React.ElementType;
  iconColorClass: string;
  iconBgClass: string;
}

interface StoryResult {
  label: string;
  value: string;
  desc: string;
  icon: React.ElementType;
  iconColorClass: string;
  iconBgClass: string;
}

interface Story {
  id: string;
  title: React.ReactNode;
  overview: string;
  challenges: StoryChallenge[];
  solutions: StorySolution[];
  results: StoryResult[];
}

const stories: Story[] = [
  {
    id: "story-2",
    title: <>零部件设计数字化平台<br/>(PDLM)</>,
    overview: "零部件设计数字化平台（PDLM）系统是一套用于研发设计阶段与供应商交互的新系统，主要支持 DFM，检具，FAE以及研发阶段的变更和特采，系统实现了上述各个流程环节的结构化与线上化。",
    challenges: [
        { title: "沟通效率低", desc: "与供应商沟通过程主要基于钉钉/电子邮件的离线协作方式，通过离线传递Office文档/PPT/模型STEF文件。", icon: MessageSquare, color: "text-red-400", border: "hover:border-red-500/50" },
        { title: "资料维护难，效率低", desc: "测试报告数据庞杂，主要依赖人力检测，问题流出率高，资料重复利用率低。", icon: Database, color: "text-orange-400", border: "hover:border-orange-500/50" },
        { title: "质量风险难追踪", desc: "先期风险无法有效传递，设计/检具/测试认证过程之间缺乏有效联动，资料版本变更频繁，经常性信息丢失。", icon: AlertTriangle, color: "text-yellow-400", border: "hover:border-yellow-500/50" },
        { title: "供应商难管理", desc: "供应商数据无法沉淀，工作成果无法量化，供应商质量难以把控，三方供应较多，进度难以把控。", icon: Users, color: "text-rose-400", border: "hover:border-rose-500/50" },
    ],
    solutions: [
        { title: "设计认证", desc: ["看稿任务流程", "3D标记", "风险管理"], icon: PenTool, iconColorClass: "text-cyan-400", iconBgClass: "bg-cyan-500/20" },
        { title: "检具认证", desc: ["检具任务流", "会签", "风险管理"], icon: Ruler, iconColorClass: "text-purple-400", iconBgClass: "bg-purple-500/20" },
        { title: "测试认证", desc: ["测试任务流", "测试大纲", "风险管理"], icon: ClipboardCheck, iconColorClass: "text-blue-400", iconBgClass: "bg-blue-500/20" },
        { title: "变更/特采", desc: ["变更创建", "特采申请", "数据同步"], icon: GitPullRequest, iconColorClass: "text-orange-400", iconBgClass: "bg-orange-500/20" },
        { title: "数据分析", desc: ["数据看板", "KT打分", "供应商绩效"], icon: BarChart2, iconColorClass: "text-green-400", iconBgClass: "bg-green-500/20" },
        { title: "模板中心", desc: ["DFM模板", "FAE模板", "检具模板"], icon: Layout, iconColorClass: "text-pink-400", iconBgClass: "bg-pink-500/20" }
    ],
    results: [
        { label: "质量成本损失", value: "降低 2000W", desc: "外发测试费用同步降低约 4000W/年。", icon: TrendingUp, iconColorClass: "text-green-500", iconBgClass: "bg-green-500/10" },
        { label: "评审效率", value: "提升 80%", desc: "单个零件评审从4小时降至30分钟。", icon: Zap, iconColorClass: "text-yellow-500", iconBgClass: "bg-yellow-500/10" },
        { label: "运营人力成本", value: "降低 12.6/年", desc: "大幅降低运营管理的人力投入成本。", icon: Users, iconColorClass: "text-blue-500", iconBgClass: "bg-blue-500/10" }
    ]
  },
  {
    id: "story-1",
    title: "设备全生命周期质量管理",
    overview: "基于自研的产品智能名片系统，打造设备零部件随身码，实现从供应商备料、装配到质检全过程扫码可视化管理。该方案能有效缩短 FAT（工厂验收测试）周期、降低返工成本，并在设备上线后持续沉淀运维数据，形成全生命周期质量闭环。",
    challenges: [
        { title: "培训成本高, 误装率高", desc: "受人员流动频繁、经验水平参差不齐影响，且现行培训主要依赖纸质手册，缺少统一且互动的指导方式，尤其在新人上岗或工艺调整时误装更为突出。", icon: FileText, color: "text-red-400", border: "hover:border-red-500/50" },
        { title: "装配留痕难管理, 追责难", desc: "关键装配过程缺乏有效的数字化留痕手段，一旦出现质量问题，难以确定责任方，延长故障排查时间。", icon: AlertTriangle, color: "text-orange-400", border: "hover:border-orange-500/50" },
        { title: "质检数据分散, 易造假", desc: "质检数据记录在多个系统中，缺乏统一整合与验证机制，存在数据篡改风险，影响质量可信度。", icon: Search, color: "text-yellow-400", border: "hover:border-yellow-500/50" },
        { title: "FAT验收失败, 回溯难", desc: "设备到达验收环节中，由于信息不透明，问题定位困难，导致返工周期长，影响生产计划。", icon: Settings, color: "text-rose-400", border: "hover:border-rose-500/50" },
    ],
    solutions: [
        { title: "1. 3D交互装配教学", desc: "基于高精度零件模型进行3D交互装配指导。配合AI语音引导与操作确认，确保操作人员充分理解装配要求。", features: ["降低误操作风险", "缩短新人培训周期"], icon: Settings, iconColorClass: "text-brand-primary", iconBgClass: "bg-brand-primary/20" },
        { title: "2. 零件随身码标签系统", desc: "为每台设备及关键部件赋予唯一二维码标识，实现部件全生命周期追踪。让每个环节都能回溯上游过程数据。", features: ["支持批量生成与管理", "无缝集成 MES 系统"], icon: QrCode, iconColorClass: "text-purple-400", iconBgClass: "bg-purple-500/20" },
        { title: "3. 移动质检录入与视频留痕", desc: "将每个环节的操作步骤、操作人员、生成数据、音视频记录做结构化存储，方便后续追溯查阅。", features: ["全过程数据结构化存储", "杜绝质量问题推诿"], icon: Video, iconColorClass: "text-blue-400", iconBgClass: "bg-blue-500/20" },
        { title: "4. 智能统计与分析", desc: "基于过程数据，总结所有质量检查项目统计设备质量合格率，并针可对多维度生成供应商质量报告。", features: ["可视化质量仪表盘", "驱动供应链持续优化"], icon: BarChart2, iconColorClass: "text-green-400", iconBgClass: "bg-green-500/20" }
    ],
    results: [
        { label: "FAT 周期", value: "缩短 30%+", desc: "通过提前发现问题，大幅减少现场验收时间。", icon: Clock, iconColorClass: "text-brand-primary", iconBgClass: "bg-brand-primary/10" },
        { label: "质量追溯", value: "100% 覆盖", desc: "关键部件全生命周期数据留痕，无死角管理。", icon: ShieldCheck, iconColorClass: "text-green-500", iconBgClass: "bg-green-500/10" },
        { label: "返工成本", value: "降低 40%", desc: "避免了因装配错误导致的昂贵返工和物料浪费。", icon: TrendingUp, iconColorClass: "text-purple-500", iconBgClass: "bg-purple-500/10" }
    ]
  },
  {
    id: "story-3",
    title: "营销获客与销售转化新入口",
    overview: "工业智能产品名片是制造业在数字时代进行营销获客与销售转化的全新入口。将每一次产品展示，都变成一次精准的高质量线索捕获。",
    challenges: [
        { title: "客户研究盲区", desc: "客户在首次接触销售前，已完成70%的自主研究：客户自主研究，静默分析，销售代表无法触达。", icon: Search, color: "text-red-400", border: "hover:border-red-500/50" },
        { title: "展示形式陈旧", desc: "传统方式（PPT/PDF）表现不佳：信息呈现静态、互动弱，客户意愿低、留资困难。", icon: FileText, color: "text-orange-400", border: "hover:border-orange-500/50" },
        { title: "决策链条复杂", desc: "委员会复杂长决策链、多角色、信息不透明：销售相应缓慢，错过最佳跟进时机，销售动作与决策阶段错配。", icon: Users, color: "text-yellow-400", border: "hover:border-yellow-500/50" },
    ],
    solutions: [
        { title: "3D模型互动展示", desc: "突破传统静态限制，提供沉浸式产品体验。", icon: Box, iconColorClass: "text-cyan-400", iconBgClass: "bg-cyan-500/20" },
        { title: "语音导览+AI实时问答", desc: "24/7 智能解答，消除客户疑虑。", icon: Mic, iconColorClass: "text-purple-400", iconBgClass: "bg-purple-500/20" },
        { title: "后台数据实时推送", desc: "捕获关键信号，快速跟进高意向客户。", icon: Radio, iconColorClass: "text-blue-400", iconBgClass: "bg-blue-500/20" },
        { title: "智能Agent引导", desc: "全流程主动引导与推进销售进程。", icon: Bot, iconColorClass: "text-green-400", iconBgClass: "bg-green-500/20" }
    ],
    results: [
        { label: "留资率", value: "提升 3-8倍", desc: "通过互动体验大幅提升客户留资意愿。", icon: Target, iconColorClass: "text-cyan-500", iconBgClass: "bg-cyan-500/10" },
        { label: "问题解决率", value: "> 90%", desc: "首次问题通过AI与自助服务快速解决。", icon: CheckCircle2, iconColorClass: "text-green-500", iconBgClass: "bg-green-500/10" },
        { label: "跟进速度", value: "提升 10倍", desc: "实时数据推送，不错过任何商机。", icon: Zap, iconColorClass: "text-yellow-500", iconBgClass: "bg-yellow-500/10" },
        { label: "转化率", value: "提升 30%", desc: "关键决策点转化效率显著提升。", icon: TrendingUp, iconColorClass: "text-rose-500", iconBgClass: "bg-rose-500/10" }
    ]
  }
];

const tabs = [
  { id: 'story-2', label: '零部件设计平台' },
  { id: 'story-1', label: '全周期质量管理' },
  { id: 'story-3', label: '营销获客与转化' },
];

export const UserStories: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [activeStoryId, setActiveStoryId] = useState<string>('story-2');

  useEffect(() => {
    if (location.hash) {
      const id = location.hash.replace('#', '');
      // Check if the hash matches a valid story ID
      if (stories.some(s => s.id === id)) {
        setActiveStoryId(id);
      }
    }
    // Always scroll to top when landing on this page or changing tabs to ensure full view
    window.scrollTo(0, 0);
  }, [location.hash]);

  const handleTabClick = (id: string) => {
    setActiveStoryId(id);
    navigate(`#${id}`);
  };

  const activeStory = stories.find(s => s.id === activeStoryId);

  return (
    <div className="bg-slate-900 min-h-screen pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Navigation Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
           {tabs.map(tab => (
             <button
               key={tab.id}
               onClick={() => handleTabClick(tab.id)}
               className={`px-6 py-3 rounded-full text-sm font-medium transition-all duration-300 transform ${
                 activeStoryId === tab.id
                   ? 'bg-brand-primary text-white shadow-lg shadow-brand-primary/25 scale-105'
                   : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white border border-white/5 hover:border-white/10'
               }`}
             >
               {tab.label}
             </button>
           ))}
        </div>

        {/* Active Story Content */}
        {activeStory && (
          <div key={activeStory.id} className="animate-in fade-in duration-500 slide-in-from-bottom-4">
            <div className="flex flex-col gap-20">
                {/* 1. Header */}
                <section className="text-center space-y-8">
                    <h1 className="text-3xl md:text-5xl font-bold text-white leading-tight">
                        {activeStory.title}
                    </h1>
                    <p className="text-slate-400 max-w-3xl mx-auto text-lg leading-relaxed">
                        {activeStory.overview}
                    </p>
                </section>

                {/* 2. Challenges */}
                <section className="space-y-12">
                    <div className="flex items-center gap-4">
                        <div className="h-10 w-1 bg-red-500 rounded-full"></div>
                        <div>
                            <h2 className="text-3xl font-bold text-white">客户面临的挑战</h2>
                            <p className="text-slate-500 mt-1">Challenges</p>
                        </div>
                    </div>
                    
                    <div className={`grid grid-cols-1 md:grid-cols-2 ${activeStory.challenges.length === 3 ? 'lg:grid-cols-3' : 'lg:grid-cols-4'} gap-6`}>
                        {activeStory.challenges.map((item, idx) => (
                            <div key={idx} className={`bg-[#0f172a] p-6 rounded-2xl border border-white/5 transition-all duration-300 ${item.border} hover:bg-[#1e293b] group`}>
                                <div className={`mb-4 p-3 bg-white/5 rounded-xl w-fit ${item.color} group-hover:scale-110 transition-transform`}>
                                    <item.icon size={24} />
                                </div>
                                <h3 className="font-bold text-white text-lg mb-3">{item.title}</h3>
                                <p className="text-sm text-slate-400 leading-relaxed text-justify">{item.desc}</p>
                            </div>
                        ))}
                    </div>
                </section>

                {/* 3. Solutions */}
                <section className="space-y-12">
                    <div className="flex items-center gap-4">
                        <div className="h-10 w-1 bg-brand-primary rounded-full"></div>
                        <div>
                            <h2 className="text-3xl font-bold text-white">我们的解决方案</h2>
                            <p className="text-slate-500 mt-1">Solution & Services</p>
                        </div>
                    </div>

                    <div className={`grid grid-cols-1 ${activeStory.solutions.length > 4 ? 'lg:grid-cols-3' : 'lg:grid-cols-2'} gap-8`}>
                        {activeStory.solutions.map((item, idx) => (
                            <div key={idx} className="bg-[#1e293b]/50 p-8 rounded-3xl border border-white/10 hover:border-brand-primary/50 transition-all flex gap-6 hover:shadow-lg hover:shadow-brand-primary/5">
                                <div className="flex-shrink-0">
                                    <div className={`w-14 h-14 ${item.iconBgClass} rounded-2xl flex items-center justify-center ${item.iconColorClass}`}>
                                        <item.icon size={28} />
                                    </div>
                                </div>
                                <div>
                                    <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
                                    {Array.isArray(item.desc) ? (
                                        <ul className="space-y-2">
                                            {item.desc.map((d, i) => (
                                                <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                                                    <span className="w-1.5 h-1.5 bg-brand-primary rounded-full"></span>
                                                    <span>{d}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <>
                                            <p className="text-slate-400 leading-relaxed mb-4">{item.desc}</p>
                                            {item.features && (
                                                <ul className="space-y-2">
                                                    {item.features.map((f, i) => (
                                                        <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                                                            <CheckCircle2 size={14} className="text-brand-primary" /> <span>{f}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            )}
                                        </>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                {/* 4. Results */}
                <section className="bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0f172a] rounded-3xl p-8 md:p-12 border border-white/10 shadow-2xl">
                    <div className="text-center mb-10">
                        <h2 className="text-3xl font-bold text-white mb-2">项目成果与价值</h2>
                        <p className="text-slate-400">Results & Impact</p>
                    </div>

                    <div className={`grid grid-cols-1 md:grid-cols-2 ${activeStory.results.length === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-8`}>
                        {activeStory.results.map((res, idx) => (
                            <div key={idx} className="text-center space-y-2 group">
                                <div className={`w-16 h-16 ${res.iconBgClass} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                                    <res.icon size={32} className={res.iconColorClass} />
                                </div>
                                <div className="text-sm font-medium text-slate-400 uppercase tracking-wider">{res.label}</div>
                                <div className={`text-2xl lg:text-3xl font-bold ${res.iconColorClass}`}>{res.value}</div>
                                <p className="text-sm text-slate-500 px-4">{res.desc}</p>
                            </div>
                        ))}
                    </div>
                </section>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};