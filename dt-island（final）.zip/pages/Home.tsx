import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Home: React.FC = () => {
  return (
    <div className="flex flex-col gap-24 pb-20">
      
      {/* 1. Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col justify-center items-center text-center px-4 overflow-hidden">
        {/* Background Grid & Effects */}
        <div className="absolute inset-0 bg-grid-pattern bg-[length:40px_40px] opacity-[0.1] pointer-events-none"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#020617]/50 to-[#020617] pointer-events-none"></div>
        
        {/* Glowing Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-primary/20 rounded-full blur-[100px] pointer-events-none animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-secondary/20 rounded-full blur-[100px] pointer-events-none animate-pulse" style={{ animationDelay: '1s' }}></div>

        <div className="relative z-10 max-w-5xl mx-auto space-y-12">
          {/* Titles */}
          <div className="space-y-6">
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-[0.2em] leading-relaxed text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-slate-400 drop-shadow-2xl">
              空间智能<br />助力工业数智化转型
            </h1>
            <p className="text-lg md:text-2xl text-slate-400 max-w-3xl mx-auto leading-relaxed tracking-wide">
              构建物理世界与数字空间的实时全息映射<br />
              推进制造业全流程数字化转型与效率跃迁
            </p>
          </div>
        </div>
      </section>

      {/* 4. Industry Solutions */}
      <section className="max-w-7xl mx-auto px-4 w-full">
        <div className="mb-20 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">全场景赋能 · 覆盖工业全生命周期</h2>
          <div className="h-1 w-20 bg-brand-primary rounded mx-auto"></div>
          <p className="mt-4 text-slate-400">INDUSTRY SOLUTIONS</p>
        </div>
        
        <div className="flex flex-col gap-32">
          {[
            { 
              title: "设计研发", 
              subtitle: "DESIGN & R&D",
              tags: ["协同设计", "虚拟仿真", "零实物试错"],
              desc: "将传统的二维图纸转化为高精度三维模型，支持多部门协同的沉浸式设计评审。通过实时物理仿真与虚拟样机验证，在制造前预演产品性能，大幅减少实物试错成本，缩短研发周期。",
              img: "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?q=80&w=800&auto=format&fit=crop",
              link: "/solutions#design"
            },
            { 
              title: "智能制造", 
              subtitle: "SMART MANUFACTURING",
              tags: ["数字孪生", "AR指导", "透明化产线"],
              desc: "构建物理产线与数字空间的实时映射，实现生产状态的透明化监控。为一线作业人员提供基于3D/AR的可视化装配指导（SOP），将复杂的工艺流程直观化，降低操作门槛与出错率。",
              img: "https://images.unsplash.com/photo-1565514020176-87d29c298d9c?q=80&w=800&auto=format&fit=crop",
              link: "/solutions#maintenance"
            },
            { 
              title: "智能销售", 
              subtitle: "SMART MARKETING",
              tags: ["虚拟展厅", "720°互动", "沉浸体验"],
              desc: "打破传统实物展示的时空局限，构建720°互动的云端虚拟展厅。客户可自由拆解产品结构、演示工作原理并进行个性化3D选配，以极致的视觉体验增强购买信心，加速销售转化。",
              img: "https://images.unsplash.com/photo-1617788138017-80ad40651399?q=80&w=800&auto=format&fit=crop",
              link: "/solutions#card"
            },
            { 
              title: "售后维护", 
              subtitle: "AFTER-SALES SERVICE",
              tags: ["3D手册", "远程专家", "故障可视化"],
              desc: "摒弃晦涩的纸质手册，提供基于3D爆炸图的交互式维修指引。结合AR远程协助技术，让专家视角实时叠加于现场设备之上，精准指导故障排查与修复，实现高效低成本的售后服务。",
              img: "https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?q=80&w=800&auto=format&fit=crop",
              link: "/solutions#maintenance"
            }
          ].map((item, idx) => (
            <div key={idx} className={`flex flex-col md:flex-row items-center gap-12 lg:gap-24 ${idx % 2 === 1 ? 'md:flex-row-reverse' : ''} group`}>
              
              {/* Image Section */}
              <div className="flex-1 w-full relative">
                 <div className="absolute -inset-4 bg-gradient-to-r from-brand-primary/20 to-brand-secondary/20 rounded-[2rem] blur-xl opacity-0 group-hover:opacity-100 transition duration-1000"></div>
                 <div className="relative rounded-[2rem] overflow-hidden aspect-[4/3] border border-white/10 shadow-2xl">
                    <img src={item.img} alt={item.title} className="w-full h-full object-cover transform group-hover:scale-110 transition duration-1000 ease-out" />
                    <div className="absolute inset-0 bg-[#020617]/10 group-hover:bg-transparent transition duration-500"></div>
                 </div>
                 {/* Floating Element Decoration */}
                 <div className={`absolute -bottom-6 ${idx % 2 === 1 ? '-left-6' : '-right-6'} w-24 h-24 bg-[#0f172a] rounded-2xl border border-white/10 flex items-center justify-center shadow-xl hidden lg:flex`}>
                    <span className="text-3xl font-bold text-white/20">0{idx + 1}</span>
                 </div>
              </div>

              {/* Text Section */}
              <div className="flex-1 space-y-6 md:py-8">
                <div className="space-y-3">
                    <div className="flex items-center gap-4">
                        <span className="text-brand-primary font-mono text-sm tracking-[0.2em] font-bold">{item.subtitle}</span>
                        <div className="h-[1px] flex-grow bg-gradient-to-r from-brand-primary/50 to-transparent"></div>
                    </div>
                    <h3 className="text-4xl lg:text-5xl font-bold text-white leading-tight">{item.title}</h3>
                </div>
                
                <div className="flex flex-wrap gap-2">
                    {item.tags.map(tag => (
                        <span key={tag} className="px-3 py-1 bg-white/5 rounded-full text-xs text-slate-400 border border-white/10">
                            {tag}
                        </span>
                    ))}
                </div>

                <p className="text-lg text-slate-400 leading-relaxed">
                    {item.desc}
                </p>

                <div className="pt-4">
                    <Link to={item.link} className="inline-flex items-center gap-2 text-white font-medium cursor-pointer group/btn hover:text-brand-primary transition-colors">
                        <span className="border-b border-white/30 pb-0.5 group-hover/btn:border-brand-primary transition-colors">了解解决方案</span>
                        <ArrowRight size={18} className="transform group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                </div>
              </div>

            </div>
          ))}
        </div>
      </section>

    </div>
  );
};