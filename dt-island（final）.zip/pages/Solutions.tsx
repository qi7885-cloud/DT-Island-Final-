import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Layers, 
  Database, 
  MousePointerClick, 
  ArrowUp, 
  ScanLine,
  Bot,
  Tablet,
  GraduationCap, 
  Projector,
  CheckCircle2,
  ArrowRight,
  PenTool
} from 'lucide-react';
import { SolutionType } from '../types';

export const Solutions: React.FC = () => {
  return (
    <div className="flex flex-col gap-24 py-12 px-4 max-w-7xl mx-auto">
      
      {/* 1. Architecture Diagram */}
      <section className="text-center space-y-12">
        <div>
          <h1 className="text-4xl font-bold mb-4">全栈式数字化解决方案架构</h1>
          <p className="text-slate-400">从数据到底层，驱动全链路价值</p>
        </div>

        <div className="relative max-w-6xl mx-auto p-8 md:p-12 rounded-3xl border border-white/5 bg-[#0b101e] overflow-hidden">
            {/* Background Lines */}
            <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            
            <div className="relative z-10 flex flex-col gap-4">
                
                {/* Layer 1: Top (App Layer) */}
                <div className="flex flex-col md:flex-row gap-6 items-stretch">
                    {/* Label Left - flex-1 and text-base to match right */}
                    <div className="flex-1 bg-[#1e293b]/80 border border-brand-primary/30 rounded-xl p-6 flex flex-col items-center justify-center text-brand-primary backdrop-blur-sm shadow-lg shadow-brand-primary/10 min-h-[120px]">
                         <MousePointerClick size={32} className="mb-2"/>
                         <span className="font-bold text-base">应用交互层</span>
                    </div>
                    {/* Content Right - flex-1 and text-base */}
                    <div className="flex-1 bg-[#0f172a]/80 border border-white/10 rounded-xl p-6 flex items-center justify-center">
                        <div className="grid grid-cols-2 gap-4 w-full">
                            {['产品名片', '智慧官网', '智能运维', '智能教辅'].map(item => (
                                <div key={item} className="bg-[#1e293b] py-3 rounded border border-white/5 text-base font-medium hover:border-brand-primary/50 hover:text-white text-slate-300 transition-colors cursor-default flex items-center justify-center shadow-sm">
                                    {item}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Arrow Up */}
                <div className="flex justify-center md:gap-6">
                    <div className="flex-1 hidden md:block"></div> {/* Spacer to align with left col */}
                    <div className="flex-1 flex justify-center">
                        <ArrowUp size={24} className="text-slate-600 animate-bounce" />
                    </div>
                </div>

                {/* Layer 2: Middle (Engine Layer) */}
                <div className="flex flex-col md:flex-row gap-6 items-stretch">
                    {/* Label Left */}
                    <div className="flex-1 bg-[#1e293b]/80 border border-brand-secondary/30 rounded-xl p-6 flex flex-col items-center justify-center text-brand-secondary backdrop-blur-sm shadow-lg shadow-brand-secondary/10 min-h-[120px]">
                         <Layers size={32} className="mb-2"/>
                         <span className="font-bold text-base">能力引擎层</span>
                    </div>
                    {/* Content Right */}
                    <div className="flex-1 bg-[#0f172a]/80 border border-white/10 rounded-xl p-6 flex items-center justify-center">
                        <div className="flex flex-col gap-4 w-full">
                            {/* Row 1 */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
                                {['小程序', 'AI知识库', 'AR', 'VR'].map(item => (
                                    <div key={item} className="bg-[#1e293b] py-3 rounded border border-white/5 text-base font-medium hover:text-brand-secondary hover:border-brand-secondary/30 text-slate-300 transition-colors cursor-default shadow-sm text-center">
                                        {item}
                                    </div>
                                ))}
                            </div>
                            {/* Row 2 */}
                            <div className="w-full">
                                <div className="bg-[#1e293b] py-3 rounded border border-white/5 text-base font-medium hover:text-brand-secondary hover:border-brand-secondary/30 text-slate-300 transition-colors cursor-default shadow-sm text-center w-full">
                                    3D编辑器
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Arrow Up */}
                <div className="flex justify-center md:gap-6">
                    <div className="flex-1 hidden md:block"></div>
                    <div className="flex-1 flex justify-center">
                         <ArrowUp size={24} className="text-slate-600 animate-bounce" />
                    </div>
                </div>

                {/* Layer 3: Bottom (Data Layer) */}
                <div className="flex flex-col md:flex-row gap-6 items-stretch">
                    {/* Label Left */}
                    <div className="flex-1 bg-[#1e293b]/80 border border-slate-600/30 rounded-xl p-6 flex flex-col items-center justify-center text-slate-400 backdrop-blur-sm min-h-[120px]">
                         <Database size={32} className="mb-2"/>
                         <span className="font-bold text-base">数据知识层</span>
                    </div>
                    {/* Content Right */}
                    <div className="flex-1 bg-[#0f172a]/80 border border-white/10 rounded-xl p-6 flex items-center justify-center">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                             {['产品文档', '多模态知识库', '过程反馈数据'].map(item => (
                                <div key={item} className="bg-[#1e293b] py-3 rounded border border-white/5 text-base font-medium text-slate-300 flex items-center justify-center shadow-sm text-center">
                                    {item}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

            </div>
        </div>
      </section>

      {/* 2. Detailed Solutions List */}
      <section className="space-y-16">
        <div className="flex items-center gap-4 mb-8">
            <div className="h-12 w-1.5 bg-brand-primary rounded-full"></div>
            <div>
                 <h2 className="text-3xl font-bold">多场景解决方案</h2>
                 <p className="text-slate-500 mt-1">深度赋能研发、营销、服务全链路</p>
            </div>
        </div>
        
        <div className="flex flex-col gap-24">
            
            {/* Card 1: 人货一体名片方案 (Right Image) */}
            <div id={SolutionType.CARD} className="group relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center scroll-mt-[200px]">
                <div className="space-y-6 order-2 lg:order-1">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-sm font-mono border border-cyan-500/20">
                        <ScanLine size={14} /> <span>Smart Card</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                        <h3 className="text-3xl font-bold text-white group-hover:text-brand-primary transition-colors">人货一体名片方案</h3>
                        <Link to="/user-stories#story-3" className="text-sm font-medium px-4 py-1.5 rounded-full border border-brand-primary/50 text-brand-primary hover:bg-brand-primary hover:text-white transition-all shadow-sm hover:shadow-brand-primary/20 active:scale-95 flex items-center gap-1">
                            查看用户故事 <ArrowRight size={14} className="ml-1" />
                        </Link>
                    </div>
                    <p className="text-slate-300 text-lg leading-relaxed">
                        每个产品有自己特有的名片，通过名片即可与产品进行3D互动、AI讲解、智能问答。打破传统物料限制，让产品"开口说话"。
                    </p>
                    
                    <div className="bg-[#1e293b]/50 p-6 rounded-xl border border-white/5 space-y-4">
                        <h4 className="font-bold text-white flex items-center gap-2"><ArrowRight size={16} className="text-brand-primary"/> 核心能力</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>720° 3D 互动展示</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>AI 智能语音讲解</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>实时问答知识库</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>一键拨号与留资</span></div>
                        </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 pt-2">
                         {['地推', '拜访', '初次接触'].map(tag => (
                            <span key={tag} className="px-3 py-1 bg-white/5 rounded text-xs text-slate-400 border border-white/10">{tag}</span>
                        ))}
                    </div>
                </div>
                <div className="relative h-[400px] rounded-2xl overflow-hidden order-1 lg:order-2 border border-white/10 shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=800&auto=format&fit=crop" 
                      alt="Robot walking a robot dog" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-60"></div>
                     <img 
                      src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://www.dtisland.com"
                      alt="Product QR Code"
                      className="absolute bottom-4 left-4 w-24 h-24 rounded-lg border-2 border-white shadow-lg z-10"
                    />
                </div>
            </div>

            {/* Card New: 研发设计解决方案 (Left Image) */}
            <div id={SolutionType.DESIGN} className="group relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center scroll-mt-[200px]">
                 <div className="relative h-[400px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1581094288338-2314dddb7ece?q=80&w=800&auto=format&fit=crop" 
                      alt="R&D Design Engineering" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-60"></div>
                </div>
                <div className="space-y-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 text-pink-400 text-sm font-mono border border-pink-500/20">
                        <PenTool size={14} /> <span>Smart Design</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                        <h3 className="text-3xl font-bold text-white group-hover:text-pink-400 transition-colors">研发设计解决方案</h3>
                        <Link to="/user-stories#story-2" className="text-sm font-medium px-4 py-1.5 rounded-full border border-pink-400/50 text-pink-400 hover:bg-pink-400 hover:text-white transition-all shadow-sm hover:shadow-pink-400/20 active:scale-95 flex items-center gap-1">
                            查看用户故事 <ArrowRight size={14} className="ml-1" />
                        </Link>
                    </div>
                    <p className="text-slate-300 text-lg leading-relaxed">
                        研发流程工具化，赋能团队、增加扁平化协作，提升工作效率。设计/检具/测试内容模版化管理，提升文档、资料的复用率，降低错误率。
                    </p>
                    <div className="bg-[#1e293b]/50 p-6 rounded-xl border border-white/5 space-y-4">
                        <h4 className="font-bold text-white flex items-center gap-2"><ArrowRight size={16} className="text-pink-400"/> 核心能力</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>内容模版化管理</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>在线协同与评审</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>多维表格/3D支持</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>研发状态可视化</span></div>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-2">
                        {['研发协同', '资料复用', '流程管理', '可视化看板'].map(tag => (
                            <span key={tag} className="px-3 py-1 bg-white/5 rounded text-xs text-slate-400 border border-white/10">{tag}</span>
                        ))}
                    </div>
                </div>
            </div>

            {/* Card 2: 官网智能助手方案 (Right Image) */}
            <div id={SolutionType.WEBSITE} className="group relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center scroll-mt-[200px]">
                <div className="space-y-6 order-2 lg:order-1">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 text-sm font-mono border border-blue-500/20">
                        <Bot size={14} /> <span>Smart Web Assistant</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                        <h3 className="text-3xl font-bold text-white group-hover:text-blue-400 transition-colors">官网智能助手方案</h3>
                        <Link to="/user-stories" className="text-sm font-medium px-4 py-1.5 rounded-full border border-blue-400/50 text-blue-400 hover:bg-blue-400 hover:text-white transition-all shadow-sm hover:shadow-blue-400/20 active:scale-95 flex items-center gap-1">
                            查看用户故事 <ArrowRight size={14} className="ml-1" />
                        </Link>
                    </div>
                    <p className="text-slate-300 text-lg leading-relaxed">
                        通过SDK一键接入官网，代理传统产品页面介绍。改善潜客自主研究阶段体验，将被动浏览转化为主动交互，显著提升转化率。
                    </p>
                    <div className="bg-[#1e293b]/50 p-6 rounded-xl border border-white/5 space-y-4">
                        <h4 className="font-bold text-white flex items-center gap-2"><ArrowRight size={16} className="text-blue-400"/> 核心能力</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>全天候无人值守</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>多模态产品展示</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>智能引导留资</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>访客行为分析</span></div>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-2">
                        {['客户自主探索', '问答交互', '引导留资'].map(tag => (
                            <span key={tag} className="px-3 py-1 bg-white/5 rounded text-xs text-slate-400 border border-white/10">{tag}</span>
                        ))}
                    </div>
                </div>
                <div className="relative h-[400px] rounded-2xl overflow-hidden order-1 lg:order-2 border border-white/10 shadow-2xl bg-slate-800 grid grid-cols-2">
                    {/* Left: Drone Image */}
                    <div className="relative h-full bg-slate-800">
                         <img 
                            src="https://images.unsplash.com/photo-1507582020474-9a35b7d455d9?q=80&w=800&auto=format&fit=crop" 
                            alt="Drone" 
                            className="absolute inset-0 w-full h-full object-cover"
                        />
                         <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0f172a]/50"></div>
                    </div>

                    {/* Right: AI Interface */}
                    <div className="relative h-full bg-[#0f172a] p-4 flex flex-col justify-center border-l border-white/5">
                        <div className="mb-4">
                            <div className="text-[10px] text-blue-400 font-bold mb-1 uppercase tracking-wider flex items-center gap-1">
                                <Bot size={12}/> AI 问答区
                            </div>
                            <div className="text-white font-bold text-sm">如何操作无人机返航?</div>
                        </div>
                        
                        <div className="space-y-3">
                            {/* User Question */}
                            <div className="bg-white/5 p-2 rounded-lg rounded-tl-none border border-white/5">
                                <p className="text-[10px] text-slate-400 leading-relaxed">用户: 低电量如何自动返航？</p>
                            </div>

                             {/* AI Answer */}
                            <div className="bg-blue-500/10 p-2 rounded-lg rounded-tr-none border border-blue-500/20">
                                <p className="text-[10px] text-slate-300 leading-relaxed">
                                    长按遥控器返航按钮，或当电量低于20%时，系统将触发智能返航模式自动飞回起飞点。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Card 3: 设备运维辅助方案 (Left Image) */}
            <div id={SolutionType.MAINTENANCE} className="group relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center scroll-mt-[200px]">
                 <div className="relative h-[400px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1581094794320-c91775743a41?q=80&w=800&auto=format&fit=crop" 
                      alt="Worker using laptop for maintenance" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-60"></div>
                </div>
                <div className="space-y-6">
                     <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 text-green-400 text-sm font-mono border border-green-500/20">
                        <Tablet size={14} /> <span>Smart Maintenance</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                        <h3 className="text-3xl font-bold text-white group-hover:text-green-400 transition-colors">设备运维辅助方案</h3>
                        <Link to="/user-stories#story-1" className="text-sm font-medium px-4 py-1.5 rounded-full border border-green-400/50 text-green-400 hover:bg-green-400 hover:text-white transition-all shadow-sm hover:shadow-green-400/20 active:scale-95 flex items-center gap-1">
                            查看用户故事 <ArrowRight size={14} className="ml-1" />
                        </Link>
                    </div>
                    <p className="text-slate-300 text-lg leading-relaxed">
                        3D展示产品结构、操作步骤、故障演示与处理流程。替代纸质二维说明书，一线人员扫码即可自查，大幅降低售后与培训成本。
                    </p>
                    <div className="bg-[#1e293b]/50 p-6 rounded-xl border border-white/5 space-y-4">
                        <h4 className="font-bold text-white flex items-center gap-2"><ArrowRight size={16} className="text-green-400"/> 核心能力</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>3D 拆解指导</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>故障排查指引</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>AR 远程专家连线</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>维修记录数字化</span></div>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-2">
                        {['售后服务', '精准运维', '运维留痕'].map(tag => (
                            <span key={tag} className="px-3 py-1 bg-white/5 rounded text-xs text-slate-400 border border-white/10">{tag}</span>
                        ))}
                    </div>
                </div>
            </div>

            {/* Card 4: 智能教辅方案 (Right Image) */}
            <div id={SolutionType.EDUCATION} className="group relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center scroll-mt-[200px]">
                <div className="space-y-6 order-2 lg:order-1">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-500/10 text-yellow-400 text-sm font-mono border border-yellow-500/20">
                        <GraduationCap size={14} /> <span>Smart Education</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                        <h3 className="text-3xl font-bold text-white group-hover:text-yellow-400 transition-colors">智能教辅方案</h3>
                        <Link to="/user-stories" className="text-sm font-medium px-4 py-1.5 rounded-full border border-yellow-400/50 text-yellow-400 hover:bg-yellow-400 hover:text-slate-900 transition-all shadow-sm hover:shadow-yellow-400/20 active:scale-95 flex items-center gap-1">
                            查看用户故事 <ArrowRight size={14} className="ml-1" />
                        </Link>
                    </div>
                    <p className="text-slate-300 text-lg leading-relaxed">
                        适用于经销商体系或新人快速启动。利用互动课件迅速传达产品理念与核心卖点，作为传统枯燥培训材料的强力补充。
                    </p>
                    <div className="bg-[#1e293b]/50 p-6 rounded-xl border border-white/5 space-y-4">
                        <h4 className="font-bold text-white flex items-center gap-2"><ArrowRight size={16} className="text-yellow-400"/> 核心能力</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>标准化话术培训</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>互动式考核</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>随时随地学习</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>学习进度追踪</span></div>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-2">
                        {['低学习门槛', '话术一致性', '产品知识考核'].map(tag => (
                            <span key={tag} className="px-3 py-1 bg-white/5 rounded text-xs text-slate-400 border border-white/10">{tag}</span>
                        ))}
                    </div>
                </div>
                 <div className="relative h-[400px] rounded-2xl overflow-hidden order-1 lg:order-2 border border-white/10 shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=800&auto=format&fit=crop" 
                      alt="Digital Education with Headset" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-60"></div>
                </div>
            </div>

            {/* Card 5: 展会辅助讲解方案 (Left Image) */}
            <div id={SolutionType.EXHIBITION} className="group relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center scroll-mt-[200px]">
                 <div className="relative h-[400px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=800&auto=format&fit=crop" 
                      alt="Immersive digital showroom with smart city model" 
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-60"></div>
                </div>
                <div className="space-y-6">
                     <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-sm font-mono border border-purple-500/20">
                        <Projector size={14} /> <span>Exhibition Assistant</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                        <h3 className="text-3xl font-bold text-white group-hover:text-purple-400 transition-colors">展会辅助讲解方案</h3>
                        <Link to="/user-stories" className="text-sm font-medium px-4 py-1.5 rounded-full border border-purple-400/50 text-purple-400 hover:bg-purple-400 hover:text-white transition-all shadow-sm hover:shadow-purple-400/20 active:scale-95 flex items-center gap-1">
                            查看用户故事 <ArrowRight size={14} className="ml-1" />
                        </Link>
                    </div>
                    <p className="text-slate-300 text-lg leading-relaxed">
                        展台大屏展示与个人扫码互动结合。解决展会现场客流量大、销售接待不过来、讲解不深入的问题。
                    </p>
                    <div className="bg-[#1e293b]/50 p-6 rounded-xl border border-white/5 space-y-4">
                        <h4 className="font-bold text-white flex items-center gap-2"><ArrowRight size={16} className="text-purple-400"/> 核心能力</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>大屏联动控制</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>观众自助漫游</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>无纸化资料分发</span></div>
                            <div className="flex items-center gap-2 text-slate-400 text-sm"><CheckCircle2 size={16} className="text-slate-600"/> <span>意向客户热力图</span></div>
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-2">
                        {['替代纸质折页', '增加现场互动', '直观可视', '现场问答'].map(tag => (
                            <span key={tag} className="px-3 py-1 bg-white/5 rounded text-xs text-slate-400 border border-white/10">{tag}</span>
                        ))}
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* 3. Case Studies */}
      <section className="bg-gradient-to-b from-[#0f172a] to-transparent p-8 md:p-12 rounded-3xl border border-white/5">
         <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">让您的成功有据可循</h2>
            <p className="text-slate-400">我们的产品已经帮助众多行业领先者实现了显著的业务增长，真实案例保障您的投入产出。</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#020617] p-8 rounded-2xl border border-white/10 hover:shadow-2xl hover:shadow-brand-primary/10 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <ArrowUp size={64} />
                </div>
                <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-5xl font-bold text-brand-primary">4倍</span>
                    <ArrowUp size={20} className="text-brand-primary/50" />
                </div>
                <p className="font-bold text-white text-lg mb-2">潜在客户增长</p>
                <p className="text-sm text-slate-500 leading-relaxed">某电梯设备厂商使用了智能名片后，客户留存与转化效率显著提升。</p>
            </div>

            <div className="bg-[#020617] p-8 rounded-2xl border border-white/10 hover:shadow-2xl hover:shadow-brand-primary/10 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <ArrowUp size={64} />
                </div>
                <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-5xl font-bold text-brand-primary">5倍</span>
                    <ArrowUp size={20} className="text-brand-primary/50" />
                </div>
                <p className="font-bold text-white text-lg mb-2">销售效率提高</p>
                <p className="text-sm text-slate-500 leading-relaxed">某头部新能源厂商通过展会辅助销售方案，缩短了产品讲解与沟通时间。</p>
            </div>

            <div className="bg-[#020617] p-8 rounded-2xl border border-white/10 hover:shadow-2xl hover:shadow-brand-primary/10 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <ArrowUp size={64} />
                </div>
                <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-5xl font-bold text-brand-primary">2倍</span>
                    <ArrowUp size={20} className="text-brand-primary/50" />
                </div>
                <p className="font-bold text-white text-lg mb-2">有效线索提升</p>
                <p className="text-sm text-slate-500 leading-relaxed">某高端数控机床厂，通过官网智能助手激活沉默访客，实现精准获客。</p>
            </div>
        </div>
      </section>

    </div>
  );
};