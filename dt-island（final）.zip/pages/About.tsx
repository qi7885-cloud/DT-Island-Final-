import React from 'react';
import { Box, Mail, MessageCircle } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="flex flex-col gap-24 py-12 px-4 max-w-7xl mx-auto">
        {/* Intro */}
        <section className="text-center max-w-4xl mx-auto space-y-8">
            <div className="w-20 h-20 bg-gradient-to-br from-brand-primary to-brand-secondary rounded-2xl mx-auto flex items-center justify-center text-white shadow-2xl shadow-brand-primary/20">
                <Box size={40} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold">杭州数屿科技有限公司</h1>
            <h2 className="text-xl text-brand-primary font-medium tracking-wide">非标设备质量控制解决方案服务商</h2>
            
            <div className="prose prose-invert prose-lg mx-auto text-left bg-[#0f172a] p-8 rounded-2xl border border-white/5">
                <p>
                    杭州数屿科技有限公司是一家聚焦制造业的人工智能企业。依托最新的AI与工业仿真技术，我们打造贯通设计、装配、FAT/SAT与运行维护全生命周期的非标设备质量控制平台，使质量过程可视、可控、可追溯。
                </p>
                <p>
                    公司产品已在头部新能源、汽车客户的生产环境验证落地，显著提升非标设备制造的一次通过率与质量一致性，降低返工、运维成本与停机风险。我们坚持产品化路线与严格的数据安全治理策略，联动产业伙伴，共建中国非标设备质量生态。
                </p>
            </div>
        </section>

        {/* Contact / CTA */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center bg-[#0f172a] rounded-3xl p-12 border border-white/5">
            <div className="space-y-8">
                <h3 className="text-3xl font-bold">联系我们</h3>
                <p className="text-slate-400">
                    无论您是希望优化现有生产流程，还是寻找全新的数字化转型方案，我们都期待与您交流。
                </p>
                
                <div className="space-y-4">
                    <div className="flex items-center gap-4 text-slate-300">
                        <Mail className="text-brand-primary" />
                        <span>hello@dtisland.com</span>
                    </div>
                    <div className="flex items-center gap-4 text-slate-300">
                        <MessageCircle className="text-brand-primary" />
                        <span>关注微信公众号：数屿科技</span>
                    </div>
                </div>
            </div>

            <div className="flex flex-col items-center justify-center space-y-4">
                <div className="bg-white p-4 rounded-xl">
                    {/* Placeholder QR Code using picsum but styled to look like QR */}
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=http://www.dtisland.com" alt="WeChat QR Code" className="w-48 h-48" />
                </div>
                <p className="text-sm text-slate-500">微信扫码进行产品体验</p>
            </div>
        </section>
    </div>
  );
};