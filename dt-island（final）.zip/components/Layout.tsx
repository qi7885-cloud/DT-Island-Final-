import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, ChevronDown, MapPin, Globe, Mail } from 'lucide-react';
import { SolutionType } from '../types';

const solutionsMenu = [
  { label: '人货一体名片方案', id: SolutionType.CARD },
  { label: '研发设计解决方案', id: SolutionType.DESIGN },
  { label: '官网智能辅助方案', id: SolutionType.WEBSITE },
  { label: '设备运维辅助方案', id: SolutionType.MAINTENANCE },
  { label: '展会辅助讲解方案', id: SolutionType.EXHIBITION },
  { label: '智能教辅方案', id: SolutionType.EDUCATION },
];

const userStoriesMenu = [
  { label: '零部件设计平台', id: 'story-2' },
  { label: '全周期质量管理', id: 'story-1' },
  { label: '营销获客与转化', id: 'story-3' },
];

const DtIslandLogo = () => (
  <div className="flex flex-col leading-none font-extrabold tracking-tight text-white select-none">
    <span className="text-[1.1rem] tracking-tight">DT</span>
    <div className="flex items-end text-[1.1rem] leading-[0.8]">
        <div className="flex flex-col items-center mr-[1px]">
            <div className="w-[4px] h-[4px] bg-[#3b82f6] mb-[1.5px]"></div>
            <div className="w-[4px] h-[8px] bg-white"></div>
        </div>
        <span>sland</span>
    </div>
  </div>
);

export const Layout: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSolutionHovered, setIsSolutionHovered] = useState(false);
  const [isUserStoryHovered, setIsUserStoryHovered] = useState(false);
  
  const location = useLocation();
  const navigate = useNavigate();

  // Handle Scroll Effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle Hash Scrolling
  useEffect(() => {
    if (location.hash) {
      const id = location.hash.replace('#', '');
      const element = document.getElementById(id);
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
      }
    } else {
      window.scrollTo(0, 0);
    }
  }, [location]);

  const handleSolutionClick = (id: string) => {
    setIsMobileMenuOpen(false);
    navigate(`/solutions#${id}`);
  };

  const handleUserStoryClick = (id: string) => {
    setIsMobileMenuOpen(false);
    navigate(`/user-stories#${id}`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#020617] text-slate-200 font-sans selection:bg-brand-primary selection:text-white">
      {/* Navbar */}
      <nav
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-[#020617]/90 backdrop-blur-md border-b border-white/10' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group py-2">
              <DtIslandLogo />
              <div className="h-6 w-[1px] bg-white/10 hidden sm:block"></div>
              <span className="text-lg font-bold text-white tracking-wide">数屿科技</span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <Link to="/" className="text-sm font-medium hover:text-brand-primary transition-colors">
                首页
              </Link>
              <Link to="/products" className="text-sm font-medium hover:text-brand-primary transition-colors">
                产品
              </Link>
              
              {/* Solutions Dropdown Trigger */}
              <div 
                className="relative h-20 flex items-center"
                onMouseEnter={() => setIsSolutionHovered(true)}
                onMouseLeave={() => setIsSolutionHovered(false)}
              >
                <Link 
                  to="/solutions" 
                  className="text-sm font-medium hover:text-brand-primary transition-colors flex items-center gap-1"
                >
                  解决方案 <ChevronDown size={14} />
                </Link>
                
                {/* Dropdown Content */}
                {isSolutionHovered && (
                  <div className="absolute top-16 left-1/2 -translate-x-1/2 w-max bg-[#0f172a] border border-white/10 shadow-xl rounded-lg overflow-hidden py-2 animate-in fade-in zoom-in-95 duration-200">
                    {solutionsMenu.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleSolutionClick(item.id)}
                        className="block w-full text-left px-4 py-3 text-sm text-slate-300 hover:bg-white/5 hover:text-brand-primary transition-colors whitespace-nowrap"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* User Stories Dropdown Trigger */}
              <div 
                className="relative h-20 flex items-center"
                onMouseEnter={() => setIsUserStoryHovered(true)}
                onMouseLeave={() => setIsUserStoryHovered(false)}
              >
                <Link 
                  to="/user-stories" 
                  className="text-sm font-medium hover:text-brand-primary transition-colors flex items-center gap-1"
                >
                  用户故事 <ChevronDown size={14} />
                </Link>
                
                {/* Dropdown Content */}
                {isUserStoryHovered && (
                  <div className="absolute top-16 left-1/2 -translate-x-1/2 w-max bg-[#0f172a] border border-white/10 shadow-xl rounded-lg overflow-hidden py-2 animate-in fade-in zoom-in-95 duration-200">
                    {userStoriesMenu.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleUserStoryClick(item.id)}
                        className="block w-full text-left px-4 py-3 text-sm text-slate-300 hover:bg-white/5 hover:text-brand-primary transition-colors whitespace-nowrap"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <Link to="/about" className="text-sm font-medium hover:text-brand-primary transition-colors">
                关于我们
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-slate-300 hover:text-white p-2"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-[#0f172a] border-b border-white/10 absolute w-full max-h-[calc(100vh-5rem)] overflow-y-auto">
            <div className="px-4 pt-2 pb-6 space-y-2">
              <Link 
                to="/" 
                className="block px-3 py-3 text-base font-medium hover:bg-white/5 rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                首页
              </Link>
              <Link 
                to="/products" 
                className="block px-3 py-3 text-base font-medium hover:bg-white/5 rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                产品
              </Link>
              <div className="px-3 py-3">
                <div className="text-base font-medium text-slate-400 mb-2">解决方案</div>
                <div className="pl-4 space-y-2 border-l border-white/10 ml-2">
                  {solutionsMenu.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleSolutionClick(item.id)}
                      className="block w-full text-left py-2 text-sm text-slate-300 hover:text-brand-primary"
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="px-3 py-3">
                <div className="text-base font-medium text-slate-400 mb-2">用户故事</div>
                <div className="pl-4 space-y-2 border-l border-white/10 ml-2">
                  {userStoriesMenu.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleUserStoryClick(item.id)}
                      className="block w-full text-left py-2 text-sm text-slate-300 hover:text-brand-primary"
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
              <Link 
                to="/about" 
                className="block px-3 py-3 text-base font-medium hover:bg-white/5 rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                关于我们
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow pt-20">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-[#0b101e] border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            
            {/* Col 1: Logo & Slogan */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <DtIslandLogo />
                <span className="text-lg font-bold text-white tracking-wide">数屿科技</span>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed pt-2">
                空间智能助力工业数智化转型
              </p>
            </div>

            {/* Col 2: Products */}
            <div>
              <h3 className="text-white font-semibold mb-4">产品与服务</h3>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><Link to="/products" className="hover:text-brand-primary">智能产品名片</Link></li>
                <li><Link to="/products" className="hover:text-brand-primary">3D编辑器</Link></li>
                <li><Link to="/solutions" className="hover:text-brand-primary">全场景解决方案</Link></li>
                <li><Link to="/solutions" className="hover:text-brand-primary">用户故事</Link></li>
              </ul>
            </div>

            {/* Col 3: Company */}
            <div>
              <h3 className="text-white font-semibold mb-4">公司动态</h3>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><Link to="/about" className="hover:text-brand-primary">关于我们</Link></li>
                <li><Link to="/about" className="hover:text-brand-primary">加入我们</Link></li>
                <li><Link to="/about" className="hover:text-brand-primary">新闻中心</Link></li>
              </ul>
            </div>

            {/* Col 4: Contact */}
            <div>
              <h3 className="text-white font-semibold mb-4">联系方式</h3>
              <ul className="space-y-3 text-sm text-slate-400">
                <li className="flex items-start gap-2">
                  <MapPin size={16} className="mt-0.5 text-brand-primary" />
                  <span>浙江省杭州市余杭区仓前街道<br/>良睦路1399号</span>
                </li>
                <li className="flex items-center gap-2">
                  <Globe size={16} className="text-brand-primary" />
                  <a href="https://www.dtisland.com/" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                    https://www.dtisland.com/
                  </a>
                </li>
                <li className="flex items-center gap-2">
                  <Mail size={16} className="text-brand-primary" />
                  <a href="mailto:hello@dtisland.com" className="hover:text-white transition-colors">
                    hello@dtisland.com
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-white/5 text-center text-xs text-slate-600">
            © {new Date().getFullYear()} Hangzhou Data Island Technology Co., Ltd. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};