import React, { useRef, useState } from 'react';
import { MousePointer2, Box, Cuboid } from 'lucide-react';

export const Interactive3DBox: React.FC = () => {
  const [rotation, setRotation] = useState({ x: -25, y: 45 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    
    // Rotate the cube based on mouse position
    setRotation({ x: y * -180, y: x * 180 });
  };

  const handleMouseLeave = () => {
    setRotation({ x: -25, y: 45 });
  };

  const cubeSize = 160;
  const translateZ = cubeSize / 2;

  // Face common styles
  const faceClass = "absolute inset-0 flex items-center justify-center border-2 backdrop-blur-sm transition-all duration-300";

  return (
    <div 
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="relative w-full aspect-video rounded-xl overflow-hidden cursor-move perspective-1000 group border border-slate-700 bg-slate-900 shadow-2xl flex items-center justify-center bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-800 to-slate-950"
    >
        <div 
            className="relative preserve-3d transition-transform duration-75 ease-out will-change-transform"
            style={{ 
                width: `${cubeSize}px`, 
                height: `${cubeSize}px`,
                transformStyle: 'preserve-3d',
                transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` 
            }}
        >
            {/* Front */}
            <div 
                className={`${faceClass} border-cyan-400/30 bg-cyan-500/10 shadow-[0_0_30px_rgba(34,211,238,0.1)]`}
                style={{ transform: `translateZ(${translateZ}px)` }}
            >
                <div className="w-full h-full grid grid-cols-2 grid-rows-2 p-4 gap-4">
                     <div className="border-r border-b border-cyan-500/20"></div>
                     <div className="border-b border-cyan-500/20"></div>
                     <div className="border-r border-cyan-500/20"></div>
                     <div></div>
                </div>
                <div className="absolute text-cyan-400 font-mono text-xs font-bold tracking-widest bg-slate-900/50 px-2 py-1 rounded">FRONT</div>
            </div>

            {/* Back */}
            <div 
                className={`${faceClass} border-purple-400/30 bg-purple-500/10 shadow-[0_0_30px_rgba(168,85,247,0.1)]`}
                style={{ transform: `rotateY(180deg) translateZ(${translateZ}px)` }}
            >
                <div className="absolute text-purple-400 font-mono text-xs font-bold tracking-widest bg-slate-900/50 px-2 py-1 rounded">BACK</div>
            </div>

            {/* Right */}
            <div 
                className={`${faceClass} border-blue-400/30 bg-blue-500/10 shadow-[0_0_30px_rgba(96,165,250,0.1)]`}
                style={{ transform: `rotateY(90deg) translateZ(${translateZ}px)` }}
            >
                <div className="absolute text-blue-400 font-mono text-xs font-bold tracking-widest bg-slate-900/50 px-2 py-1 rounded">RIGHT</div>
            </div>

            {/* Left */}
            <div 
                className={`${faceClass} border-blue-400/30 bg-blue-500/10 shadow-[0_0_30px_rgba(96,165,250,0.1)]`}
                style={{ transform: `rotateY(-90deg) translateZ(${translateZ}px)` }}
            >
                <div className="absolute text-blue-400 font-mono text-xs font-bold tracking-widest bg-slate-900/50 px-2 py-1 rounded">LEFT</div>
            </div>

            {/* Top */}
            <div 
                className={`${faceClass} border-slate-400/30 bg-slate-500/10 shadow-[0_0_30px_rgba(148,163,184,0.1)]`}
                style={{ transform: `rotateX(90deg) translateZ(${translateZ}px)` }}
            >
                <div className="absolute text-slate-400 font-mono text-xs font-bold tracking-widest bg-slate-900/50 px-2 py-1 rounded">TOP</div>
            </div>

            {/* Bottom */}
            <div 
                className={`${faceClass} border-slate-400/30 bg-slate-500/10 shadow-[0_0_30px_rgba(148,163,184,0.1)]`}
                style={{ transform: `rotateX(-90deg) translateZ(${translateZ}px)` }}
            >
                <div className="absolute text-slate-400 font-mono text-xs font-bold tracking-widest bg-slate-900/50 px-2 py-1 rounded">BOTTOM</div>
            </div>

            {/* Core Center Dot */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-[0_0_20px_white] animate-pulse"></div>
            
            {/* Axis Lines (Cosmetic) */}
            <div className="absolute top-1/2 left-1/2 w-[200px] h-[1px] bg-red-500/40 -translate-x-1/2 -translate-y-1/2 pointer-events-none" style={{ transform: 'translateZ(0)' }}></div>
            <div className="absolute top-1/2 left-1/2 w-[1px] h-[200px] bg-green-500/40 -translate-x-1/2 -translate-y-1/2 pointer-events-none" style={{ transform: 'translateZ(0)' }}></div>
            <div className="absolute top-1/2 left-1/2 w-[1px] h-[200px] bg-blue-500/40 -translate-x-1/2 -translate-y-1/2 pointer-events-none" style={{ transform: 'rotateX(90deg) translateZ(0)' }}></div>
        </div>
        
        {/* Overlay UI */}
        <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end pointer-events-none select-none">
            <div>
                <h4 className="text-white font-bold text-lg">3D Modeling Engine</h4>
                <p className="text-slate-400 text-sm">Interactive Cube Demo</p>
            </div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-mono bg-cyan-950/30 px-2 py-1 rounded border border-cyan-500/20">
                <MousePointer2 size={12} />
                <span>DRAG TO ROTATE</span>
            </div>
        </div>
    </div>
  );
};
