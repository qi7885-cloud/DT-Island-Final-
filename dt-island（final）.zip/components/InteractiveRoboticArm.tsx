import React, { useRef, useState } from 'react';
import { MousePointer2, MoveVertical } from 'lucide-react';

export const InteractiveRobotHand: React.FC = () => {
  // x controls rotation, y controls openness
  // Default: x=0.5 (center rotation), y=0.0 (fully open)
  const [state, setState] = useState({ x: 0.5, y: 0.0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    setState({ x, y });
  };
  
  const handleMouseLeave = () => {
    // Default to open (y=0), 3/4 view (x=0.5)
    setState({ x: 0.5, y: 0.0 });
  };

  // Logic: 
  // Mouse Y (0 top -> 1 bottom). 
  // User wants: Up (0) -> Open, Down (1) -> Closed.
  // So openness = 1 - y.
  const openness = 1 - state.y; 
  
  // Rotation for 3D feel
  // Base rotation 225 degrees (Viewing from the Back-Left side).
  // This ensures that when the fingers curl "back" (into -Z), we can see them.
  // Range: 165 to 285 degrees.
  const rotY = (state.x - 0.5) * 120 + 225; 
  
  // Slight tilt based on openness, but kept mostly vertical
  const rotX = (state.y - 0.5) * 10; 

  // Finger Angles
  // 0 openness (Closed) -> 90 deg curl
  // 1 openness (Open) -> 0 deg curl
  const baseCurl = (1 - openness) * 80;
  const midCurl = (1 - openness) * 90;
  const tipCurl = (1 - openness) * 80;

  // Spread fingers slightly when open
  const spread = openness * 10; 

  interface CuboidProps {
    w: number;
    h: number;
    d: number;
    color: string;
    style?: React.CSSProperties;
  }

  const Cuboid: React.FC<CuboidProps> = ({ w, h, d, color, style }) => {
    const hw = w/2; const hh = h/2; const hd = d/2;
    return (
      <div className="absolute preserve-3d" style={{ width: w, height: h, ...style }}>
        {/* Front */}
        <div className={`absolute inset-0 ${color} opacity-90 border border-cyan-500/20`} style={{ transform: `translateZ(${hd}px)` }} />
        {/* Back */}
        <div className={`absolute inset-0 ${color} opacity-90 border border-cyan-500/20`} style={{ transform: `rotateY(180deg) translateZ(${hd}px)` }} />
        {/* Right */}
        <div className={`absolute inset-0 ${color} opacity-80 border border-cyan-500/20`} style={{ width: d, height: h, left: (w-d)/2, transform: `rotateY(90deg) translateZ(${hw}px)` }} />
        {/* Left */}
        <div className={`absolute inset-0 ${color} opacity-80 border border-cyan-500/20`} style={{ width: d, height: h, left: (w-d)/2, transform: `rotateY(-90deg) translateZ(${hw}px)` }} />
        {/* Top */}
        <div className={`absolute inset-0 ${color} opacity-100 border border-cyan-500/30`} style={{ width: w, height: d, top: (h-d)/2, transform: `rotateX(90deg) translateZ(${hh}px)` }} />
        {/* Bottom */}
        <div className={`absolute inset-0 ${color} opacity-40 border border-cyan-500/20`} style={{ width: w, height: d, top: (h-d)/2, transform: `rotateX(-90deg) translateZ(${hh}px)` }} />
      </div>
    );
  };

  const Finger: React.FC<{ 
    w: number; h: number; d: number; 
    x: number; y: number; z: number;
    rotY?: number; 
    scale?: number;
  }> = ({ w, h, d, x, y, z, rotY = 0, scale = 1 }) => {
    // Segment lengths
    const ph1 = h * 0.45;
    const ph2 = h * 0.35;
    const ph3 = h * 0.20;

    return (
      <div className="absolute preserve-3d transition-transform duration-100 ease-out"
           style={{ transform: `translate3d(${x}px, ${y}px, ${z}px) rotateY(${rotY}deg) scale(${scale})` }}>
           
           {/* Knuckle Joint */}
           <div className="preserve-3d transition-transform duration-100 ease-out origin-bottom"
                style={{ transform: `rotateX(${baseCurl}deg)` }}>
                
                {/* Proximal Phalanx */}
                <div className="absolute bottom-0 -left-[50%]">
                    <Cuboid w={w} h={ph1} d={d} color="bg-cyan-900" style={{ transform: `translateY(${-ph1}px)` }} />
                    <div className="absolute top-[-4px] left-[2px] right-[2px] h-1 bg-cyan-400 shadow-[0_0_5px_cyan]"></div>
                </div>

                {/* PIP Joint */}
                <div className="absolute left-0 preserve-3d transition-transform duration-100 ease-out"
                     style={{ transform: `translateY(${-ph1}px) rotateX(${midCurl}deg)` }}>
                     
                     {/* Middle Phalanx */}
                     <div className="absolute bottom-0 -left-[50%]">
                        <Cuboid w={w} h={ph2} d={d} color="bg-cyan-800" style={{ transform: `translateY(${-ph2}px)` }} />
                     </div>

                     {/* DIP Joint */}
                     <div className="absolute left-0 preserve-3d transition-transform duration-100 ease-out"
                          style={{ transform: `translateY(${-ph2}px) rotateX(${tipCurl}deg)` }}>
                          
                          {/* Distal Phalanx */}
                          <div className="absolute bottom-0 -left-[50%]">
                              <Cuboid w={w} h={ph3} d={d} color="bg-cyan-700" style={{ transform: `translateY(${-ph3}px)` }} />
                          </div>
                     </div>
                </div>
           </div>
      </div>
    );
  };

  const Thumb: React.FC<{
    x: number; y: number; z: number;
  }> = ({ x, y, z }) => {
     // Thumb logic is slightly different
     const tBaseCurl = (1 - openness) * 40;
     const tMidCurl = (1 - openness) * 60;
     const tTipCurl = (1 - openness) * 80;

     return (
        <div className="absolute preserve-3d transition-transform duration-100 ease-out"
             style={{ transform: `translate3d(${x}px, ${y}px, ${z}px) rotateY(-45deg) rotateZ(30deg)` }}>
            
            {/* Base */}
            <div className="preserve-3d transition-transform duration-100 ease-out origin-bottom"
                  style={{ transform: `rotateX(${tBaseCurl}deg)` }}>
                   <div className="absolute bottom-0 -left-[10px]">
                      <Cuboid w={20} h={40} d={18} color="bg-cyan-900" style={{ transform: `translateY(-40px)` }} />
                   </div>
                   
                   {/* Mid */}
                   <div className="absolute left-0 preserve-3d transition-transform duration-100 ease-out"
                        style={{ transform: `translateY(-40px) rotateX(${tMidCurl}deg)` }}>
                        <div className="absolute bottom-0 -left-[10px]">
                           <Cuboid w={18} h={35} d={16} color="bg-cyan-800" style={{ transform: `translateY(-35px)` }} />
                        </div>

                        {/* Tip */}
                         <div className="absolute left-0 preserve-3d transition-transform duration-100 ease-out"
                            style={{ transform: `translateY(-35px) rotateX(${tTipCurl}deg)` }}>
                            <div className="absolute bottom-0 -left-[10px]">
                               <Cuboid w={16} h={30} d={14} color="bg-cyan-700" style={{ transform: `translateY(-30px)` }} />
                            </div>
                         </div>
                   </div>
            </div>
        </div>
     )
  }

  return (
    <div 
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="w-full h-full bg-[#0B1120] relative overflow-hidden cursor-ns-resize perspective-1000 select-none flex items-center justify-center group"
    >
        {/* Background Grid */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.05)_1px,transparent_1px)] bg-[size:40px_40px] [transform:perspective(500px)_rotateX(60deg)_translateY(100px)_scale(2)] pointer-events-none"></div>

        {/* 3D Scene Root */}
        <div className="relative preserve-3d transition-transform duration-100 ease-out" 
             style={{ transform: `rotateX(${rotX}deg) rotateY(${rotY}deg) translateY(50px)` }}>
            
            {/* Palm */}
            <Cuboid w={80} h={90} d={25} color="bg-slate-800" style={{ transform: 'translateZ(0)' }} />
            {/* Palm Details */}
            <div className="absolute w-12 h-12 bg-cyan-500/20 rounded-full blur-md top-[20px] left-[14px] translate-z-4"></div>
            <div className="absolute w-16 h-1 bg-cyan-900 top-[10px] left-[2px] translate-z-[13px]"></div>
            <div className="absolute w-16 h-1 bg-cyan-900 bottom-[10px] left-[2px] translate-z-[13px]"></div>

            {/* Wrist */}
            <div className="absolute top-[45px] left-[-25px]">
               <Cuboid w={50} h={40} d={20} color="bg-slate-900" style={{ transform: 'translateY(25px)' }} />
            </div>

            {/* Fingers (Position relative to palm center) */}
            {/* Pinky */}
            <Finger w={14} h={70} d={14} x={-32} y={-45} z={0} rotY={-spread * 1.5} scale={0.85} />
            {/* Ring */}
            <Finger w={16} h={85} d={16} x={-12} y={-45} z={0} rotY={-spread * 0.5} scale={0.95} />
            {/* Middle */}
            <Finger w={17} h={95} d={17} x={10} y={-45} z={0} rotY={spread * 0.5} scale={1.0} />
            {/* Index */}
            <Finger w={16} h={85} d={16} x={30} y={-45} z={0} rotY={spread * 1.5} scale={0.95} />
            
            {/* Thumb */}
            <Thumb x={45} y={10} z={5} />

        </div>

        {/* UI Overlay */}
        <div className="absolute top-8 left-0 right-0 text-center pointer-events-none">
            <h3 className="text-cyan-400 font-bold tracking-widest text-xs drop-shadow-[0_0_5px_rgba(6,182,212,0.8)]">CYBERNETIC HAND</h3>
            <div className="w-16 h-0.5 bg-cyan-500/50 mx-auto mt-1"></div>
        </div>
        
        <div className="absolute bottom-8 left-0 right-0 flex justify-center pointer-events-none opacity-60 group-hover:opacity-100 transition-opacity">
            <div className="flex items-center gap-2 text-white text-[10px] font-mono bg-slate-900/80 px-3 py-1.5 rounded-full border border-cyan-500/30 backdrop-blur-md shadow-lg">
                <MoveVertical size={12} className="text-cyan-400" />
                <span>MOVE MOUSE UP/DOWN TO ANIMATE</span>
            </div>
        </div>
    </div>
  );
};