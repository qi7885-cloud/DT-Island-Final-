export enum SolutionType {
  CARD = 'card',
  WEBSITE = 'website',
  MAINTENANCE = 'maintenance',
  EXHIBITION = 'exhibition',
  EDUCATION = 'education',
  DESIGN = 'design',
}